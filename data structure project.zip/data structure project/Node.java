package project;

public class Node <T> {

	public T data;
	public Node <T> next;

	
	public Node( T value ) {
		data = value ;
		next = null;	
	}
	
	public Node() {
		data = null;
		next = null;	
	}

	public T getData() {
		return data;
	}


}