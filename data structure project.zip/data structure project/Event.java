package project;

public class Event implements Comparable<Event> {
	
	private String event_title;
	private String event_date;
	private String event_time;
	private String event_location;
	private Contact event_contact;
	
	public Event(String title,String date,String time , String location , Contact contact) { 
	event_title = title;	
	event_date = date;
	event_time = time;
	event_location = location;
	event_contact = contact;
	}
	
	public Event(String title, String date, String time, String location) {
		event_title = title;	
		event_date = date;
		event_time = time;
		event_location = location;
	}

	public String getEvent_date() {
		return event_date;
	}

	public String getEvent_time() {
		return event_time;
	}

	public String getEvent_title() {
		return event_title;
	}
	
	public String toString() {
		return "\nEvent title:" + event_title + "\nEvent date:" + event_date + "\nEvent time:" + event_time
				+ "\nEvent location:" + event_location + "\nContact in " + event_title + ":" + event_contact.getContact_name() + "\n";
	}

	public String getEvent_location() {
		return event_location;
	}

	public Contact getEvent_contact() {
		return event_contact;
	}

	public int compareTo(Event data) {
		if ( event_title.charAt(0)<=data.getEvent_title().charAt(0))
			return 1;
			return -1;	
	}
	
} // end of class Event
