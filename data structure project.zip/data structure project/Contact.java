package project;

public class Contact implements Comparable<Contact> {

private String Contact_name;  
private String phone_number;	
private String email;
private String address;
private String birthday;
private String notes;

private LinkedList<Event> EventsofContact; 


public Contact(String name , String phonenumber , String Email , String Address ,String Birthday , String Note) {

	Contact_name = name;
	phone_number = phonenumber;
	email = Email;
	address = Address;
	birthday = Birthday;
	notes = Note;
	EventsofContact = new LinkedList<Event>();
	
}

public void addevent( Event newEvent ) { 
	EventsofContact.addSotertedEvents(newEvent);		
}

public LinkedList<Event> getEventsofContact() {
	return EventsofContact;
}

public String getContact_name() {
	return Contact_name;
}

public String getPhone_number() {
	return phone_number;
}

public String getEmail() {
	return email;
}

public String getAddress() {
	return address;
}

public String getBirthday() {
	return birthday;
}

public String toString() { 

	return "\nName:" + Contact_name + "\nPhone Number:" + phone_number + "\nEmail Address:" + email + "\nAddress:" + address +
    "\nBirthday:" + birthday + "\nNotes:" + notes + "\n";
}

public int compareTo(Contact data) {
	if ( Contact_name.charAt(0)<=data.getContact_name().charAt(0))
		return 1;
		return -1;
}


} //end of class Contact
