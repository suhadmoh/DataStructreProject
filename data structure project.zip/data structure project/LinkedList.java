package project;

public class LinkedList<T> {

	Node<T> head;
	Node<T> current;

	public LinkedList() {
		head = null;
		current = null;
	}

	public boolean isEmpty() {
		return head == null;
	}

	public boolean isFull() {
		return false;
	}

	public boolean isLast() {
		return current.next == null;
	}

	public void findFirst() {
		current = head;
	}

	public void findnext() {
		current = current.next;
	}

	public void update(T value) {
		current.data = value;
	}

	public T retrive() {
		return current.data;
	}

	public void insert(T value) {

		Node<T> newNode = new Node<T>(value);

		if (head == null)
			head = current = newNode;

		else {
			newNode.next = current.next;
			current.next = newNode;
			current = newNode;
		}

	}

	public void remove() {

		if (head == null) {
			System.out.println("List is empty!");
			return;
		}

		else {

			if (head == current)
				head = current = head.next;

			else {

				Node<T> temp = head;
				while (temp.next != current)
					temp = temp.next;
				temp.next = current.next;

				if (current.next == null)
					current = head;
				else
					current = current.next;

			}

		}

	}
	
	// override of method remove.
	public void remove(T value) {

		if (head == null) {
			System.out.println("List is EmpTy!");
			return;
		}

		else {

			if (head.data == value)
				head = head.next;

			else {
				Node<T> q = null;
				Node<T> temp = head;

				while (temp != null) {
					if (temp.data == value)
						q.next = temp.next;
					q = temp;
					temp = temp.next;
				}

			}
		}

	}

	// End of the main methods

	public boolean isUnique(T value) {
		Node<T> temp = head;

		while (temp != null) {
			if (((Contact) temp.data).getContact_name().equalsIgnoreCase(((Contact) value).getContact_name())
					|| ((Contact) temp.data).getPhone_number().equalsIgnoreCase(((Contact) value).getPhone_number()))
				return false;
			temp = temp.next;
		}
		return true;
	}

	public void display() {
		Node<T> temp = head;

		if (temp == null) {
			System.out.println("The List is Empty!");
			return;
		}

		while (temp != null) {
			System.out.println(temp.data.toString());
			temp = temp.next;
		}

	}

	public Contact searchContactname(String name) {

		if (head==null)
			return null;

		Node<T> temp = head;
		while (temp != null) {
			if (((Contact) temp.data).getContact_name().equals(name))
				return (Contact) temp.data;
			temp = temp.next;
		}

		return null;
	}

	public Contact searchContactnNumber(String number) {

		if (isEmpty())
			return null;

		Node<T> temp = head;
		while (temp != null) {
			if (((Contact) temp.data).getPhone_number().equals(number))
				return (Contact) temp.data;
			temp = temp.next;
		}
		return null;
	}

	public void addSotertedContact(T value) {

		Node<T> newcontact = new Node<T>(value);

		Node<T> first = head;
		Node<T> second = null;

		if (head == null) {
			head = current = newcontact;
			return;
		}

		if (((Contact) value).compareTo((Contact) head.data) == 1) {
			newcontact.next = head;
			head = current = newcontact;
			return;
		}

		while (first != null && ((Contact) value).compareTo((Contact) first.data) == -1) {
			second = first;
			first = first.next;
		}

		second.next = newcontact;
		newcontact.next = first;
		current = newcontact;
	}

	public void addSotertedEvents(T value) {

		Node<T> newEvent = new Node<T>(value);

		Node<T> first = head;
		Node<T> second = null;

		if (head == null) {
			head = current = newEvent;
			return;
		}

		if (((Event) value).compareTo((Event) head.data) == 1) {
			newEvent.next = head;
			head = current = newEvent;
			return;
		}

		while (first != null && ((Event) value).compareTo((Event) first.data) == -1) {
			second = first;
			first = first.next;
		}

		second.next = newEvent;
		newEvent.next = first;
		current = newEvent;
	}
	
} // End of class linked list
