package project;

public interface Comparable<T> {
public int compareTo( T data );
}
