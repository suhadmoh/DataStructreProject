package project;
import java.util.Scanner;

// section 55025
// Group 8 
// Albatool Alkahlan 443200696
// Ghala Alsugair 443200968 
// Suhad Aljuraysh 443200660

public class Phonebook {

	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		LinkedList<Contact> Mycontacts = new LinkedList<Contact>();
		LinkedList<Event> MyEvents = new LinkedList<Event>();

		System.out.println("Welcome to the Linked Tree Phonebook!");
		int choice = 0;

		do {
			System.out.println("\nPlease choose an option:\n" + "1. Add a contact\n" + "2. Search for a contact\n"
					+ "3. Delete a contact\n" + "4. Schedule an event\n" + "5. Print event details\n"
					+ "6. Print contacts by first name\n" + "7. Print all events alphabetically\n" + "8. print all contacts that share an event.\n" + "9. Exit\n");

			System.out.println("Enter your choice:\n");
			choice = input.nextInt();

			switch (choice) {

			case 1: // Add a contact:

				System.out.println("\nEnter the contact's name:");
				input.nextLine();
				String name = input.nextLine();
				System.out.println("Enter the contact's phone number:");
				String phoneNumber = input.nextLine();
				System.out.println("Enter the contact's email address:");
				String email = input.nextLine();
				System.out.println("Enter the contact's address:");
				String address = input.nextLine();
				System.out.println("Enter the contact's birthday:");
				String birthday = input.nextLine();
				System.out.println("Enter any notes for the contact:");
				String notes = input.nextLine();

				Contact newContact = new Contact(name, phoneNumber, email, address, birthday, notes);

				// req3:
				if (!Mycontacts.isUnique(newContact))
					System.out.println(
							"\nContact cannot be added.\nWe have obtained a duplicate of the contact name or phone number you provided.\n");
				else {
					Mycontacts.addSotertedContact(newContact);
					System.out.println("\nContact added successfully!");
				}

				Mycontacts.display(); // not require just for test
				break;

			case 2: // Search for a contact:

				if (Mycontacts.isEmpty())
					System.out.println("\nThe list is empty!\nThere are No Contacts on the list to search for");

				else {

					System.out.println("\nEnter your search criteria:");
					System.out.println(
							"1. Name\n" + "2. Phone Number\n" + "3. Email Address\n" + "4. Address\n" + "5. Birthday");
					int choice_2 = input.nextInt();

					switch (choice_2) {

					case 1: // search by name:

						System.out.println("\nEnter The contact name:");
						input.nextLine();
						Contact searchName = Mycontacts.searchContactname(input.nextLine());

						if (searchName != null) {
							System.out.println("\nContact Found!");
							System.out.println(searchName.toString());
						} else
							System.out.println("\nThe Contact you searched for was Not found");

						break;

					case 2: // search by phone number:

						System.out.println("\nEnter The phone number:");
						input.nextLine();
						Contact searchPhonenumber = Mycontacts.searchContactnNumber(input.nextLine());

						if (searchPhonenumber != null) {
							System.out.println("\nContact Found!");
							System.out.println(searchPhonenumber.toString());
						} else
							System.out.println("\nThe phone number you searched for was Not found");

						break;

					// req4: search and print all contacts that share Email Address,Address,birthday
					// (return a list)

					case 3: // search by Email Address:

						System.out.println("\nEnter The Email Address:");
						input.nextLine();
						LinkedList<Contact> emails = searchContact(Mycontacts, input.nextLine(), 3);

						if (!emails.isEmpty()) {
							System.out.println("\nContact Found!");
							emails.display();
						} else
							System.out.println("\nThe Email you searched for was Not Found");
						break;

					case 4: // search by Address:

						System.out.println("\nEnter The Address:");
						input.nextLine();
						LinkedList<Contact> Address = searchContact(Mycontacts, input.nextLine(), 4);

						if (!Address.isEmpty()) {
							System.out.println("\nContact Found!");
							Address.display();
						} else
							System.out.println("\nThe Address you searched for was Not Found");

						break;

					case 5: // search by birthday:

						System.out.println("\nEnter The birthday:");
						input.nextLine();
						String searchBirthday = input.nextLine();
						LinkedList<Contact> birthdays = searchContact(Mycontacts, searchBirthday, 5);

						if (!birthdays.isEmpty()) {
							System.out.println("\nContact Found!");
							birthdays.display();
						}

						else
							System.out.println("\nThe birthday you searched for was Not Found");
						break;

					default:
						System.out.println("\nOPPS! We think that you miswrote your choice.");
					}

				} // end else

				break;

			case 3: // Delete a contact

				System.out.println("Enter The contact name you want to delete: ");
				input.nextLine();
				Contact Name = Mycontacts.searchContactname(input.nextLine());

				if (Name != null) {

					delete(Name, Mycontacts, MyEvents);
					System.out.println("\nThe Contact has been successfully deleted!\n");
					Mycontacts.display(); // test only

				} else
					System.out.println("\nThe Contact you want to Delete is not on the list");

				break;

			case 4: // Schedule an event:

				System.out.println("Enter contact name:");
				input.nextLine();
				String contact_name = input.nextLine();

				// req9
				Contact contactInEvent = Mycontacts.searchContactname(contact_name);

				if (contactInEvent != null) {

					System.out.println("Enter event title:");
					String title = input.nextLine();

					System.out.println("Enter event Date:[DD:MM:YYYY]");
					String date = input.nextLine();

					System.out.println("Enter event time:[HH:MM]");
					String time = input.nextLine();

					System.out.println("Enter Event location:");
					String location = input.nextLine();

					// req11
					if (cheak_for_events_conflect(title, date, time, location, contactInEvent, MyEvents))
						System.out.println(
								"\nWe catch a conflict in the date and time provided. \nEvent could not be schedled.");

					else {

						Event newEvent = new Event(title, date, time, location, contactInEvent);
						MyEvents.addSotertedEvents(newEvent);
						contactInEvent.addevent(newEvent);
						System.out.println("\nEvent scheduled successfuly!\n");
					}

					MyEvents.display(); // test purpose only

				} else
					System.out.println(
							"\nThe contact name you have provid is not on the Phonebook\nEvent chould not be scheduled");

				break;

			case 5: // print event details:

				// if there is no event do not complete
				if (!MyEvents.isEmpty()) {
					System.out.println("Enter search criteria:");
					System.out.println("1. contact name\n" + "2. Event tittle");

					int choice_4 = input.nextInt();

					switch (choice_4) {
					case 1:
						System.out.println("Enter the contact name:");
						input.nextLine();
						String Contact_name = input.nextLine();
						Contact contact = Mycontacts.searchContactname(Contact_name);
						
						if (contact != null) {
							LinkedList<Event> EventOfContact = contact.getEventsofContact();
							if (!EventOfContact.isEmpty()) {
								System.out.println("Event found!");
								EventOfContact.display();
							}
							else
								System.out.println("\nThere is no Event with the contact name profided.");
						} else
							System.out.println("\nThe contact name you have provid is not on the Phonebook");

						break;

					case 2:
						System.out.println("Enter the event title:");
						input.nextLine();
						String event_title = input.nextLine();
						LinkedList<Event> TitleOfEvent = SearchEventbyTitle(MyEvents, event_title);
						if (!TitleOfEvent.isEmpty()) {
							System.out.println("Event found!");
							TitleOfEvent.display();
						}
						else
							System.out.println("\nThere is no Event with the profided Title.");

						break;
					default:
						System.out.println("OPPS! We think that you miswrote your choice.");
					}

				} else
					System.out.println("\nThere is no Events in the list to print");
				break;

			case 6: // print contacts by first name: 

				if (!Mycontacts.isEmpty()) { // need to put a condition here
					System.out.println("Enter the first name of the contact:");
					input.nextLine();
					String first_name = input.nextLine();

					LinkedList<Contact> firstnameContacts = PrintByFirstName(Mycontacts, first_name);
					
					if(!firstnameContacts.isEmpty()) {
						System.out.println("Contacts found!");
						firstnameContacts.display();
					}
					else
						System.out.println("looks like the name you provided us does not exist.");

				} else
					System.out.println("The list is Empty.\nThere is No contacts to print.");

				break;

			case 7: // print all events alphabetically in O(n)
				
				MyEvents.display();
				break;

			case 8: // print all contacts that share an event ( not in the sample run )

				LinkedList<Contact> list = contactsSharedEvents(Mycontacts);
				if (!list.isEmpty())
					list.display();
				else
					System.out.println("no evant with the input provided.");
				break;

			case 9: // exit

				System.out.println("Thank you for using our Program!\nGoodbye!");
				break;

			default:
				System.out.println("\nOPPS! We think that you miswrote your choice.\nplease try again");

			} // end switch

		} while (choice != 9);

	} // end main

	public static void delete(Contact contact, LinkedList<Contact> Mycontacts, LinkedList<Event> MyEvents) {

		LinkedList<Event> deletedevents = contact.getEventsofContact();

		// deleting the contact events from the the big events list. O(n^2)

		if (!deletedevents.isEmpty() && !MyEvents.isEmpty()) {

			deletedevents.findFirst();

			while (!deletedevents.isLast()) {

				Event eventToCheack = deletedevents.retrive();

				MyEvents.findFirst();

				while (!MyEvents.isLast()) {

					if (eventToCheack.equals(MyEvents.retrive())) {
						MyEvents.remove();
						break;
					}

					MyEvents.findnext();
				}

				// for the last event in MyEvents.
				if (eventToCheack.equals(MyEvents.retrive()))
					MyEvents.remove();

				deletedevents.findnext();
			}

			// for the last event in the events list of the contact.
			Event eventToCheack = deletedevents.retrive();

			MyEvents.findFirst();
			while (!MyEvents.isLast()) {

				if (eventToCheack.equals(MyEvents.retrive()))
					MyEvents.remove();

				MyEvents.findnext();
			}
			// for the last event in MyEvents.
			if (eventToCheack.equals(MyEvents.retrive()))
				MyEvents.remove();
		}

		// if the events list of the contact is empty delete the contact without
		// deleting events.
		Mycontacts.remove(contact);

	}

	public static LinkedList<Contact> searchContact(LinkedList<Contact> Mycontacts, String data, int choice) {

		LinkedList<Contact> List = new LinkedList<Contact>();
		Mycontacts.findFirst();

		while (!Mycontacts.isLast()) {
			Contact contact = Mycontacts.retrive();

			if (choice == 3 && contact.getEmail().equals(data))
				List.addSotertedContact(contact);
			else if (choice == 4 && contact.getAddress().equals(data))
				List.addSotertedContact(contact);
			else if (choice == 5 && contact.getBirthday().equals(data))
				List.addSotertedContact(contact);

			Mycontacts.findnext();
		}

		// for the last contact in MyContacts
		Contact contacts = Mycontacts.retrive();
		if (choice == 3 && contacts.getEmail().equals(data))
			List.addSotertedContact(contacts);
		else if (choice == 4 && contacts.getAddress().equals(data))
			List.addSotertedContact(contacts);
		else if (choice == 5 && contacts.getBirthday().equals(data))
			List.addSotertedContact(contacts);

		return List;
	}

	public static LinkedList<Contact> PrintByFirstName(LinkedList<Contact> Mycontacts, String Firstname) {

		LinkedList<Contact> list = new LinkedList<Contact>();

		Mycontacts.findFirst();

		while (!Mycontacts.isLast()) {
			String contactFirstName = Mycontacts.retrive().getContact_name().split(" ")[0];
			if (contactFirstName.equalsIgnoreCase(Firstname)) {
				list.addSotertedContact(Mycontacts.retrive());
				;
			}
			Mycontacts.findnext();
		}
		// for the last contact on the list
		String contactFirstName = Mycontacts.retrive().getContact_name().split(" ")[0];
		if (contactFirstName.equalsIgnoreCase(Firstname)) {
			list.addSotertedContact(Mycontacts.retrive());
		}
		return list;
	}

	public static LinkedList<Event> SearchEventbyTitle(LinkedList<Event> MyEvents, String Name) {

		MyEvents.findFirst();

		LinkedList<Event> listOFevents = new LinkedList<Event>();

		while (!MyEvents.isLast()) {
			if (Name.equalsIgnoreCase(MyEvents.retrive().getEvent_title()))
				listOFevents.addSotertedEvents(MyEvents.retrive());
			MyEvents.findnext();
		}

		// for the last event in myEvents
		if (Name.equalsIgnoreCase(MyEvents.retrive().getEvent_title()))
			listOFevents.addSotertedEvents(MyEvents.retrive());

		return listOFevents;
	}

	public static boolean cheak_for_events_conflect(String title, String date, String time, String location,Contact contact, LinkedList<Event> MyEvents) {
		
		boolean conflict = false;

		if (MyEvents.isEmpty())
			return false;

		else {

			MyEvents.findFirst();

			while (!MyEvents.isLast()) {

				Event event_check = MyEvents.retrive();
				if (event_check.getEvent_date().equals(date) && event_check.getEvent_time().equals(time)) {
					// first case (shared events)- title and location is the same but contact is different.
					if (event_check.getEvent_title().equals(title) && event_check.getEvent_location().equals(location)) {
						if (!event_check .getEvent_contact().equals(contact))
							conflict = false;
						else
							return true; // in this case there is a duplicate of the event with same contact.
					} else
						return true;
				}

				MyEvents.findnext();
			}

			// last node
			if (MyEvents.retrive().getEvent_date().equals(date) && MyEvents.retrive().getEvent_time().equals(time)) {
				// first case (shared event)- title and location is the same but contact is
				// different.
				if (MyEvents.retrive().getEvent_title().equals(title)
						&& MyEvents.retrive().getEvent_location().equals(location)) {
					if (!MyEvents.retrive().getEvent_contact().equals(contact))
						conflict = false;
					else
						return true; // in this case there is a duplicate of the event with same contact.
				} else
					return true;
			}

		}

		return conflict;

	}

	public static LinkedList<Contact> contactsSharedEvents(LinkedList<Contact> Mycontacts) { // print contacts with  shared events.
																							

		System.out.println("\nPlease enter the information for the event you are looking for\n");

		System.out.println("Enter event title:");
		input.nextLine();
		String title = input.nextLine();

		System.out.println("Enter event Date:");
		String date = input.nextLine();

		System.out.println("Enter event time:");
		String time = input.nextLine();

		System.out.println("Enter Event location:");
		String location = input.nextLine();

		LinkedList<Contact> contactslist = new LinkedList<Contact>();

		if(!Mycontacts.isEmpty()) {
		Mycontacts.findFirst();
		
		while (!Mycontacts.isLast()) {
			
			LinkedList<Event> list = Mycontacts.retrive().getEventsofContact();
			
			if(!list.isEmpty()) {
			list.findFirst();
			while (!list.isLast()) {
				if (title.equalsIgnoreCase(list.retrive().getEvent_title()))
					if (date.equalsIgnoreCase(list.retrive().getEvent_date()))
						if (time.equalsIgnoreCase(list.retrive().getEvent_time()))
							if (location.equalsIgnoreCase(list.retrive().getEvent_location()))
								contactslist.addSotertedContact(Mycontacts.retrive());
				list.findnext();

			}
			if (title.equalsIgnoreCase(list.retrive().getEvent_title()))
				if (date.equalsIgnoreCase(list.retrive().getEvent_date()))
					if (time.equalsIgnoreCase(list.retrive().getEvent_time()))
						if (location.equalsIgnoreCase(list.retrive().getEvent_location()))
							contactslist.addSotertedContact(Mycontacts.retrive());
			}
			
			Mycontacts.findnext();
		}

		LinkedList<Event> list = Mycontacts.retrive().getEventsofContact();
		if (!list.isEmpty()) {
			list.findFirst();
			while (!list.isLast()) {
				if (title.equalsIgnoreCase(list.retrive().getEvent_title()))
					if (date.equalsIgnoreCase(list.retrive().getEvent_date()))
						if (time.equalsIgnoreCase(list.retrive().getEvent_time()))
							if (location.equalsIgnoreCase(list.retrive().getEvent_location()))
								contactslist.addSotertedContact(Mycontacts.retrive());
				list.findnext();

			}
			if (title.equalsIgnoreCase(list.retrive().getEvent_title()))
				if (date.equalsIgnoreCase(list.retrive().getEvent_date()))
					if (time.equalsIgnoreCase(list.retrive().getEvent_time()))
						if (location.equalsIgnoreCase(list.retrive().getEvent_location()))
							contactslist.addSotertedContact(Mycontacts.retrive());
		}
	}
		return contactslist;
	}

	
}// end of PHONEBOOK class
